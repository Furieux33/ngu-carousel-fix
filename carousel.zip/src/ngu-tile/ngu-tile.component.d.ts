export declare class NguTileComponent {
    classes: boolean;
}
