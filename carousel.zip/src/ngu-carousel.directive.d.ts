export declare class NguCarouselItemDirective {
}
export declare class NguCarouselNextDirective {
}
export declare class NguCarouselPrevDirective {
}
export declare class NguCarouselPointDirective {
}
