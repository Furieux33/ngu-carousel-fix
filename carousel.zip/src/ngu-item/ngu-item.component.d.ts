export declare class NguItemComponent {
    classes: boolean;
}
