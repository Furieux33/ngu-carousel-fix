export { NguCarouselModule } from './src/ngu-carousel.module';
export { NguCarousel, NguCarouselStore } from './src/ngu-carousel/ngu-carousel.interface';
export { NguCarouselService } from './src/ngu-carousel.service';
//# sourceMappingURL=index.js.map